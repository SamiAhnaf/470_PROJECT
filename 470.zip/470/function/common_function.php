<?php 
  // include('./includes/connect.php');   removed  beacause the error causing in user registraion including

  function getProducts(){
    global $con;
    //checking something brand or category isset or not if not set then show all  
     if(!isset($_GET['category'])){
        if (!isset($_GET['brand'])) {
      // creating query for selecting data
                  $search_query="select * from products order by rand() limit 0,6";
                  //query execution
                  $search_result=mysqli_query($con,$search_query);
                  // fetching data from database throw all data using the query  result;
                  while($product_data=mysqli_fetch_assoc($search_result)){
                       $product_id=$product_data['product_id'];
                       $product_title=$product_data['product_title'];
                       $product_description= $product_data['product_description'];
                    //    $product_keywords=$product_data['	product_keywords'];
                       $category_id=$product_data['category_id'];
                       $brand_id=$product_data['brand_id'];
                       $product_image1=$product_data['product_image1'];
                       $product_image2=$product_data['product_image2'];
                       $product_image3=$product_data['product_image3'];
                       $product_price=$product_data['product_price'];
                    //    $date=$product_data['date'];
                    //    $status=$product_data['status'];

                    echo "
                  
                    <div class='col-md-4 mb-2'>
                    <div class='card'>
                        <img src='./admin_area/product_image/ $product_image1' class='card-img-top' alt='$product_title'>
                        <div class='card-body'>
                            <h5 class='card-title'>$product_title</h5>
                            <p class='card-text'>$product_description</p>
                            <p class='card-text'>Price:$product_price</p>
                            <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to card</a>
                            <a href='product_details.php?product_id=$product_id' class='btn btn-dark'>View More</a>
                        </div>
                    </div>
  
                </div> 
                    
                    
                    ";
                  }
  }
}
  }

  function getAllProducts(){
    global $con;
    //checking something brand or category isset or not if not set then show all  
     if(!isset($_GET['category'])){
        if (!isset($_GET['brand'])) {
      // creating query for selecting data
                  $select_query="select * from products order by rand()";
                  //query execution
                  $select_result=mysqli_query($con,$select_query);
                  // fetching data from database throw all data using the query  result;
                  while($product_data=mysqli_fetch_assoc($select_result)){
                       $product_id=$product_data['product_id'];
                       $product_title=$product_data['product_title'];
                       $product_description= $product_data['product_description'];
                    //    $product_keywords=$product_data['	product_keywords'];
                       $category_id=$product_data['category_id'];
                       $brand_id=$product_data['brand_id'];
                       $product_image1=$product_data['product_image1'];
                       $product_image2=$product_data['product_image2'];
                       $product_image3=$product_data['product_image3'];
                       $product_price=$product_data['product_price'];
                    //    $date=$product_data['date'];
                    //    $status=$product_data['status'];

                    echo "
                  
                    <div class='col-md-4 mb-2'>
                    <div class='card'>
                        <img src='./admin_area/product_image/ $product_image1' class='card-img-top' alt='$product_title'>
                        <div class='card-body'>
                            <h5 class='card-title'>$product_title</h5>
                            <p class='card-text'>$product_description</p>
                            <p class='card-text'>Price:$product_price</p>
                            <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to card</a>
                            <a href='product_details.php?product_id=$product_id' class='btn btn-dark'>View More</a>
                        </div>
                    </div>
  
                </div> 
                    
                    
                    ";
                  }
  }
}



  }

// sorting fucntion for category 
function sortCategory() {
 global $con;
    //checking something brand or category isset or not if not set then show all  
     if(isset($_GET['category'])){
        $category_id=$_GET['category'];
      // creating query for selecting data
                  $select_query="select * from products where category_id=$category_id";
                  //query execution
                  $select_result=mysqli_query($con,$select_query);
                 //counting rows for showing outof stock message
                 $rowCount=mysqli_num_rows($select_result);
                 if ($rowCount==0 ) {
                    echo "<h2 class='text-center text-danger'>This Category product is out of stock</h2> ";
                 }

                  // fetching data from database throw all data using the query  result;
                  while($product_data=mysqli_fetch_assoc($select_result)){
                       $product_id=$product_data['product_id'];
                       $product_title=$product_data['product_title'];
                       $product_description= $product_data['product_description'];
                    //    $product_keywords=$product_data['	product_keywords'];
                       $category_id=$product_data['category_id'];
                       $brand_id=$product_data['brand_id'];
                       $product_image1=$product_data['product_image1'];
                       $product_image2=$product_data['product_image2'];
                       $product_image3=$product_data['product_image3'];
                       $product_price=$product_data['product_price'];
                    //    $date=$product_data['date'];
                    //    $status=$product_data['status'];

                    echo "
                  
                    <div class='col-md-4 mb-2'>
                    <div class='card'>
                        <img src='./admin_area/product_image/ $product_image1' class='card-img-top' alt='$product_title'>
                        <div class='card-body'>
                            <h5 class='card-title'>$product_title</h5>
                            <p class='card-text'>$product_description</p>
                            <p class='card-text'>Price:$product_price</p>
                            <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to card</a>
                            <a href='product_details.php?product_id=$product_id' class='btn btn-dark'>View More</a>
                        </div>
                    </div>
  
                </div> 
                    
                    
                    ";
                  }
                  
  }
}
function sortBrand() {
    global $con;
       //checking something brand or category isset or not if not set then show all  
        if(isset($_GET['brand'])){
           $brand_id=$_GET['brand'];
         // creating query for selecting data
                     $select_query="select * from products where brand_id=$brand_id";
                     //query execution
                     $select_result=mysqli_query($con,$select_query);
                    //counting rows for showing outof stock message
                    $rowCount=mysqli_num_rows($select_result);
                    if ($rowCount==0 ) {
                       echo "<h2 class='text-center text-danger'>This Brand product is out of stock</h2> ";
                    }
   
                     // fetching data from database throw all data using the query  result;
                     while($product_data=mysqli_fetch_assoc($select_result)){
                          $product_id=$product_data['product_id'];
                          $product_title=$product_data['product_title'];
                          $product_description= $product_data['product_description'];
                       //    $product_keywords=$product_data['	product_keywords'];
                          $category_id=$product_data['category_id'];
                          $brand_id=$product_data['brand_id'];
                          $product_image1=$product_data['product_image1'];
                          $product_image2=$product_data['product_image2'];
                          $product_image3=$product_data['product_image3'];
                          $product_price=$product_data['product_price'];
                       //    $date=$product_data['date'];
                       //    $status=$product_data['status'];
   
                       echo "
                     
                       <div class='col-md-4 mb-2'>
                       <div class='card'>
                           <img src='./admin_area/product_image/ $product_image1' class='card-img-top' alt='$product_title'>
                           <div class='card-body'>
                               <h5 class='card-title'>$product_title</h5>
                               <p class='card-text'>$product_description</p>
                               <p class='card-text'>Price:$product_price</p>
                               <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to card</a>
                               <a href='product_details.php?product_id=$product_id' class='btn btn-dark'>View More</a>
                           </div>
                       </div>
     
                   </div> 
                       
                       
                       ";
                     }
                     
     }
   }

 function getBrands(){
    global $con;
 //selecting data from database
 $select_query="select * from `brands`";
 $select_result=mysqli_query($con,$select_query);
 //fetching the selected data
 $brand_data=mysqli_fetch_assoc($select_result);
//  echo $brand_data['brand_title'];
//looping throw the seelected data to show everything
while($brand_data=mysqli_fetch_assoc($select_result)){
    $brand_title=$brand_data['brand_title'];
    $brand_id=$brand_data['brand_id'];
    echo "<li class='nav-item'>
    <a class='nav-link text-light' href='index.php?brand= $brand_id'>
    $brand_title </a>
</li> ";
}

 }
function  getCategory(){
    global $con ;
   //selecting data from database
   $select_query="select * from `categories`";
   $select_result=mysqli_query($con,$select_query);
   //fetching the selected data
   $category_data=mysqli_fetch_assoc($select_result);
  //  echo $category_data['brand_title'];
  //looping throw the seelected data to show everything
  while($category_data=mysqli_fetch_assoc($select_result)){
      $category_title=$category_data['category_title'];
      $category_id=$category_data['category_id'];
      echo "<li class='nav-item'>
      <a class='nav-link text-light' href='index.php?category= $category_id'>
      $category_title </a>
  </li> ";

}
}
//searching fucntion navigation and name is for accessing the value of input field

function searchProduct(){
  global $con; 
  //accessing the value of  navingation seach bar  everytime using isset checing is clicked or not
   if(isset($_GET['search_data_product'])){
    $search_data=$_GET['search_data'];
    // creating query for searching the data
                $select_query="select * from `products` where 	product_keywords like '%$search_data%'";
                //query execution
                $select_result=mysqli_query($con,$select_query);
              //counting data rows for showing not found message
              $rowCount=mysqli_num_rows($select_result);
                    if ($rowCount==0 ) {
                       echo "<h2 class='text-center text-danger'>Sorry! Your Product is out of stock</h2> ";
                    }

                // fetching data from database throw all data using the query  result;
                while($product_data=mysqli_fetch_assoc($select_result)){
                     $product_id=$product_data['product_id'];
                     $product_title=$product_data['product_title'];
                     $product_description= $product_data['product_description'];
                  //    $product_keywords=$product_data['	product_keywords'];
                     $category_id=$product_data['category_id'];
                     $brand_id=$product_data['brand_id'];
                     $product_image1=$product_data['product_image1'];
                     $product_image2=$product_data['product_image2'];
                     $product_image3=$product_data['product_image3'];
                     $product_price=$product_data['product_price'];
                  //    $date=$product_data['date'];
                  //    $status=$product_data['status'];

                  echo "
                
                  <div class='col-md-4 mb-2'>
                  <div class='card'>
                      <img src='./admin_area/product_image/ $product_image1' class='card-img-top' alt='$product_title'>
                      <div class='card-body'>
                          <h5 class='card-title'>$product_title</h5>
                          <p class='card-text'>$product_description</p>
                          <p class='card-text'>Price:$product_price</p>
                          <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to card</a>
                          <a href='product_details.php?product_id=$product_id' class='btn btn-dark'>View More</a>
                      </div>
                  </div>

              </div> 
                  
                  
                  ";
                }


              }
}


//view mor function
function viewMore(){
  global $con;
  //checking something brand or category isset or not if not set then show all  
  if(isset($_GET['product_id'])) {
   if(!isset($_GET['category'])){
      if (!isset($_GET['brand'])) {
        $product_id=$_GET['product_id'];
    // creating query for selecting data
                $search_query="select * from `products` where product_id= $product_id";
                //query execution
                $search_result=mysqli_query($con,$search_query);
                // fetching data from database throw all data using the query  result;
                while($product_data=mysqli_fetch_assoc($search_result)){
                     $product_id=$product_data['product_id'];
                     $product_title=$product_data['product_title'];
                     $product_description= $product_data['product_description'];
                  //    $product_keywords=$product_data['	product_keywords'];
                     $category_id=$product_data['category_id'];
                     $brand_id=$product_data['brand_id'];
                     $product_image1=$product_data['product_image1'];
                     $product_image2=$product_data['product_image2'];
                     $product_image3=$product_data['product_image3'];
                     $product_price=$product_data['product_price'];
                  //    $date=$product_data['date'];
                  //    $status=$product_data['status'];

                  echo "
                
                  <div class='col-md-4 mb-2'>
                  <div class='card'>
                      <img src='./admin_area/product_image/ $product_image1' class='card-img-top' alt='$product_title'>
                      <div class='card-body'>
                          <h5 class='card-title'>$product_title</h5>
                          <p class='card-text'>$product_description</p>
                          <p class='card-text'>Price:$product_price</p>
                          <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to card</a>
                          <a href='index.php' class='btn btn-dark'>Go Back</a>
                      </div>
                  </div>

              </div> 
                  
                
              
              <div class='col-md-8'>
               <div class='row'>
                 <div class='col-md-12'>
                   <h4 class='text-center text-info mb-5'>Related Product</h4>
                   </div>
                   <div class='col-md-6'>
                   <img src='./admin_area/product_image/ $product_image2' class='card-img-top' alt='$product_title'>
               
                    </div>
                   <div class='col-md-6'>
                   <img src='./admin_area/product_image/ $product_image3' class='card-img-top' alt='$product_title'>
   
                   </div>
   
                 </div>
   
                     </div>



                  ";
                }
}
}


}

}

// ip address fucntion
function getIPAddress() {  
  //whether ip is from the share internet  
   if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
              $ip = $_SERVER['HTTP_CLIENT_IP'];  
      }  
  //whether ip is from the proxy  
  elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
              $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
   }  
//whether ip is from the remote address  
  else{  
           $ip = $_SERVER['REMOTE_ADDR'];  
   }  
   return $ip;  
}  
// $ip = getIPAddress();  
// echo 'User Real IP Address - '.$ip;  

//fucntion cart for add to cart
function cart() {
    if (isset($_GET['add_to_cart'])) {
      global $con;
      $ip = getIPAddress();  
      $get_product_id=$_GET['add_to_cart'];
      $select_query="select * from `cart_details` where 	ip_address='$ip'  and   
       product_id =$get_product_id";
       $select_result=mysqli_query($con,$select_query);
       //counting the row
       $rowCount=mysqli_num_rows($select_result);
       if ($rowCount>0 ) {
          echo "<script> alert('This Item is already aded inside the cart') </script> ";
          echo "<script>window.open('index.php','_self') </script> ";
       }
       else {
        $insert_query="insert into `cart_details` (product_id,ip_address,quantity) values($get_product_id,'$ip',0)";
        $insert_result=mysqli_query($con, $insert_query);
        echo "<script> alert('This Item is aded to the cart') </script> ";
        echo "<script>window.open('index.php','_self') </script> ";
       }
    }

}
//CART item showing

function cartItem(){
  if (isset($_GET['add_to_cart'])) {
    global $con;
    $ip = getIPAddress();  
    $select_query="select * from `cart_details` where 	ip_address='$ip'";
     $select_result=mysqli_query($con,$select_query);
     //counting the row
     $cartItemCount=mysqli_num_rows($select_result);
  }
    else {
      global $con;
      $ip = getIPAddress();  
      $select_query="select * from `cart_details` where 	ip_address='$ip'";
       $select_result=mysqli_query($con,$select_query);
       //counting the row
       $cartItemCount=mysqli_num_rows($select_result);
     }

  echo $cartItemCount;
}

// total price calculation function
function TotalPrice() {
  global $con;
  $total=0;
  $ip = getIPAddress();
  $cart_query="select * from `cart_details` where 	ip_address= '$ip' ";
  $cart_result=mysqli_query($con,$cart_query);
  while($row=mysqli_fetch_array($cart_result)) {
    $product_id=$row['product_id'];
    $select_query="select * from `products` where 	product_id= $product_id";
    $select_result=mysqli_query($con,$select_query); 
     while($row_product_price=mysqli_fetch_array($select_result)){
       $product_price=array($row_product_price['product_price']);
       $product_values=array_sum($product_price);
       $total+=$product_values;

  }
}
 echo $total;

}

//getting user order details
function user_order_details(){
  global $con;
  $username=$_SESSION['username'];
  $get_details="select * from `user_table` where 	user_name='$username'";
  $details_result=mysqli_query($con,$get_details);
  while($row_query=mysqli_fetch_array( $details_result)){
    $user_id=$row_query['user_id'];
    if(!isset($_GET['edit_account'])){
       if(!isset($_GET['my_orders'])){
       $get_orders="select * from `user_orders` where 	user_id= $user_id and order_status='pending'";
       $orders_result=mysqli_query($con,$get_orders);
       $row_count=mysqli_num_rows($orders_result);
       if ( $row_count>0){
        echo "<h3 class='text-center text-success mt-5 mb-2'>You have <span class='text-danger'>$row_count</span> pending orders</h3>  <p class='text-center'> <a href='profile.php?my_orders' class='text-dark'>Order Details </a></p>";
       
       }
       else {
        echo "<h3 class='text-center text-success mt-5 mb-2'>You have <span class='text-danger'>0</span> pending orders</h3>  <p class='text-center'> <a href='../index.php' class='text-dark'>Explore Products </a></p>";
       }
       }
    }

  }
}


?>