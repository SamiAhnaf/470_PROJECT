<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> User Login</title>
</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <!-- bootstap link  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
</head>
<body>
     <div class="container-fluid my-3">
        <h2 class="text-center "> User Login</h2>
            <div class="row d-flex align-items-center justify-content-center ">
          <div class="col-lg-12 col-xl-6">    
            <form action="" method="post" >
               <!-- name field -->
                 <div class="form-outline mb-4">
                   <label for="user_username" class="form-label">Username</label>
                   <input type="text" id="user_username" class="form-control" placeholder="Enter your user name" autocomplete="off" required   name="user_username">
                 </div>
             
                    <!-- password field -->
               <div class="form-outline mb-4">
                   <label for="user_password" class="form-label">Password</label>
                   <input type="password" id="user_password" class="form-control" placeholder="Enter your user password" autocomplete="off" required    name="user_password">
                 </div>
               
                  
                 
                 <div class="mt-3 pt-2">
                        <input type="Submit" value="Login" class="bg-info border-0 px-3 py-2 text-light" name="user_login">
                        <p class="small fw-bold mt-2 pt-1">Don't have an account?  <a href="user_registration.php" class="text-danger"> Register</a> </p>

                 </div>
 
          </form>
        </div>
      

            </div>

    </div>
</body>
</html>
</body>
</html>
<?php
include('../includes/connect.php'); 
include('../function/common_function.php'); 
@session_start();
////////////included ifle/////////////



if(isset($_POST['user_login'])){
 $user_name=$_POST['user_username'];
 $user_password=$_POST['user_password'];
 
 $select_query="select * from `user_table` where user_name='$user_name'";
 $select_execute=mysqli_query($con, $select_query);
 
 $row_count=mysqli_num_rows($select_execute);
$row_data=mysqli_fetch_assoc($select_execute);
$user_ip=getIPAddress();
//for cart item 
$cart_query="select * from `cart_details` where ip_address='$user_ip'";
$cart_result = mysqli_query($con,$cart_query);
if ($cart_result) {
    $cart_row_count = mysqli_num_rows($cart_result);
} else {
    // handle the error, for example:
    echo "Query failed: " . mysqli_error($con);
}


if($row_count>0){
  $_SESSION['username']=$user_name; 
 if($user_password==$row_data['user_password']) {
  // echo "<script>alert('Log in successfull') </script>";
    if ($row_count==1 and  $cart_row_count==0 ){
      $_SESSION['username']=$user_name;
      echo "<script>alert('Log in successfull') </script>";
      echo "<script>window.open('profile.php','_self') </script>";
    }
    else {
      $_SESSION['username']=$user_name;
      echo "<script>alert('Log in successfull') </script>";
      echo "<script>window.open('payment.php','_self') </script>";

    }



 }
 else {
  echo "<script>alert('Invalid credentials') </script>";
 }

}
else {
  echo "<script>alert('Invalid credentials') </script>";

}

}      





?>