<?php 
 include('../includes/connect.php'); 

//checking the insert button is clicked or not
if(isset($_POST['insert_product'])){
//fetching data from input field with the POST MEHTOD
    $product_title= $_POST['product-title'];
    $description= $_POST['description'];
    $product_keywords= $_POST['product_keywords'];
    $product_category= $_POST['product_category'];
    $product_brands= $_POST['product_brands'];
    $product_price= $_POST['product_price'];
    $product_status='true';
    //accessing images
    $product_image1= $_FILES['product_image1'] ['name'];
    $product_image2= $_FILES['product_image2'] ['name'];
    $product_image3= $_FILES['product_image3'] ['name'];
    //accessing image temp name
    $temp_image1= $_FILES['product_image1'] ['tmp_name'];
    $temp_image2= $_FILES['product_image2'] ['tmp_name'];
    $temp_image3= $_FILES['product_image3'] ['tmp_name'];
 //checking the empty conditon 
 if( $product_title=='' or $description=='' or $product_keywords=='' or  $product_category=='' or $product_brands=='' or  $product_price=='' or  $product_image1=='' or $product_image2=='' or $product_image3==''){
    echo "<script>alert('Please fill the avaible fields') </script>";
    exit();
 }
 else {
    //moving uploaded image. it will be done by move method .....
    move_uploaded_file($temp_image1,"./product_image/ $product_image1");
    move_uploaded_file($temp_image2,"./product_image/ $product_image2");
    move_uploaded_file($temp_image3,"./product_image/ $product_image3");
 }

//making insert query
 $insert_query="insert into `products` (product_title,product_description,product_keywords,category_id,brand_id,product_image1,product_image2,product_image3,product_price,date,status) values('$product_title',' $description','$product_keywords','$product_category',' $product_brands','$product_image1','$product_image2','$product_image3','$product_price',NOW(),'$product_status')";

//executing the query
$insert_result=mysqli_query($con,$insert_query);
if ($insert_result){
    echo "<script>alert('Your Product is inserted successfully') </script>";
 
}


}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Product Admin-dashboard</title>
       <!-- bootstrap link  -->
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <!-- fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    <!-- mycss  -->
    <link rel="stylesheet" href="../mystyle.css">
</head>
<body class="bg-light">

  <div class="container">
     <h1 class="text-center mt-3">Insert Product</h1>
   <!-- enctype is for inserting picture in database -->
     <form action="" method="post" enctype="multipart/form-data">
<!-- 
       title -->
        <div class="form-outline mb-4 w-50 m-auto">
         <label for="product-title" class="form-label" > Product Title</label>
         <input type="text" name="product-title" id="product-title" class="form-control" placeholder="Enter product title" autocompleter="off" required>

        </div>

<!-- 
       description -->

       <div class="form-outline mb-4 w-50 m-auto">
         <label for="description" class="form-label" > Product Description</label>
         <input type="text" name="description" id="description" class="form-control" placeholder="Enter product description" autocompleter="off" required>

        </div>
<!-- 
       keywords-->

       <div class="form-outline mb-4 w-50 m-auto">
         <label for="product_keywords" class="form-label" > Product Keywords</label>
         <input type="text" name="product_keywords" id="product_keywords" class="form-control" placeholder="Enter product keywords" autocompleter="off" required>

        </div>
<!-- 
       categories-->
       <div class="form-outline mb-4 w-50 m-auto">
        <select name="product_category"  class="form-select">
          <option value="">Select a category</option>

       <!-- making category dynamic     -->
          <?php 
         //selecting data from database
         $select_query="select * from categories";
         $select_result=mysqli_query($con,$select_query);
         //fetching the selected data
         $category_data=mysqli_fetch_assoc($select_result);
        //  echo $category_data['brand_title'];
        //looping throw the seelected data to show everything
        while($category_data=mysqli_fetch_assoc($select_result)){
            $category_title=$category_data['category_title'];
            $category_id=$category_data['category_id'];
            echo "<option value='$category_id'>$category_title</option>";
        }
         ?>
        </select>
</div>
     <!--    brands-->

       <div class="form-outline mb-4 w-50 m-auto">
        <select name="product_brands"  class="form-select">
          <option value="">Select a brand</option>
           <!-- making Brand  dynamic     -->
          <?php 
         //selecting data from database
         $select_query="select * from brands";
         //run the query
         $select_result=mysqli_query($con,$select_query);
         //fetching the selected data
         
        //  echo $brand_data['brand_title'];
        //looping throw the seelected data to show everything
        while($brand_data=mysqli_fetch_assoc($select_result)){
          $brand_title=$brand_data['brand_title'];
          $brand_id=$brand_data['brand_id'];
          echo "<option value='$brand_id'>$brand_title</option>";
        }
         ?>
        </select>
</div>

       <!-- images -->
<div class="form-outline mb-4 w-50 m-auto">
         <label for="product_image1" class="form-label" > Product image1</label>
         <input type="file" name="product_image1" id="product_image1" class="form-control" required>

        </div>
           <!-- image2 -->
<div class="form-outline mb-4 w-50 m-auto">
         <label for="product_image2" class="form-label" > Product image2</label>
         <input type="file" name="product_image2" id="product_image2" class="form-control" >

        </div>
           <!-- image3 -->
<div class="form-outline mb-4 w-50 m-auto">
         <label for="product_image3" class="form-label" > Product image3</label>
         <input type="file" name="product_image3" id="product_image3" class="form-control" >

        </div>
   <!-- pricing  -->
   <div class="form-outline mb-4 w-50 m-auto">
         <label for="product_price" class="form-label" > Product price</label>
         <input type="text" name="product_price" id="product_price" class="form-control" placeholder="Enter product price" autocompleter="off" required>

        </div>

        <!-- pricing -->
        <div class="form-outline mb-4 w-50 m-auto">
         <input type="submit" name="insert_product"  class="btn btn-info mb-3 mx-3"  value="Insert Product" >

        </div>

     </form>

  </div>
    



  <div class="bg-info p-3 text-center my-0">
            <p>Copyright © 2023 | Designed by Tusher Ahmed </p>
        </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
</body>
</html>