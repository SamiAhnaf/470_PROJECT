<?php
 include('../includes/connect.php');  
//accessing the input field through name and POST 
if(isset($_POST['insert_brand']))
{
  $brand_title=$_POST['brand_title'];
  //creating a select query
  $select_query="select * from `brands` where  brand_title='$brand_title'";
  //execute
  $result_select=mysqli_query($con,$select_query);
  $number=mysqli_num_rows($result_select);
  if($number>0){
    echo "<script> alert('Your Brand is present in database') </script>";
  }
  else {
  //creating the query
  $insert_query="insert into `brands` (brand_title) values('$brand_title')";
  //executing the query
  $result=mysqli_query($con,$insert_query);
  if($result){
    echo "<script> alert('Your Brand has been added successfully') </script>";
  }
}
}

?>

<h2 class="text-center">Insert Brands </h2>
<form action="" method="post" class="mb-2">

<div class="input-group w-90 mb-2">
  <span class="input-group-text bg-info" id="basic-addon1"><i class="fa-solid fa-receipt"></i></span>
  <input type="text" class="form-control" name="brand_title" placeholder="Insert Brands" aria-label="Username" aria-describedby="basic-addon1">
</div>
<div class="input-group  mb-2">
  <input type="submit" class="bg-info p-2 my-3 border-0" name="insert_brand" value="Insert brands" placeholder="Insert Brands" aria-label="Username" aria-describedby="basic-addon1" >
</div>

</form> 