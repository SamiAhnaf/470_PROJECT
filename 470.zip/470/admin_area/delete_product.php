<?php  
if(isset($_GET['delete_product'])){
    $delete_id=$_GET['delete_product'];
    //delete query

    $delete_product="delete from `products` where product_id= $delete_id";
    $delete_result=mysqli_query($con,$delete_product);
    if($delete_result){
        echo "<script>alert('Product deleted Successfully')</script> ";
        echo "<script>window.open('index2.php','_self')</script> ";
    }

}

?>