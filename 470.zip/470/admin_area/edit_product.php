<?php 
if(isset($_GET['edit_product'])){
 $edit_id=$_GET['edit_product'];
 $get_edit_data="select * from `products` where product_id=$edit_id";
 $result_edit=mysqli_query($con,$get_edit_data);
 $row=mysqli_fetch_assoc( $result_edit);
  $product_title=$row['product_title'];
  $product_price=$row['product_price'];

}
//updating the product in database

if(isset($_POST['update_product'])){
$product_title=$_POST['product_title'];
$product_price=$_POST['product_price'];
if($product_title=='' or $product_title=='' ){
  echo "<script> alert('Please fill all the fields') </script>";
}
$update_product="update `products` set product_title='$product_title', product_price='$product_price' where product_id= $edit_id";
$update_result=mysqli_query($con,$update_product);
if($update_result){
  echo "<script> alert('Your product is updated successfully') </script>";
  echo "<script> window.open('index2.php','_self') </script>";

}
}

?>

<div class="container mt-5">
<h1 class="text-center">Edit Product</h1>
<form action="" method="post" enctype="multipart/form-data">
  <div class="form-outline w-50 m-auto mb-4">
   <label for="product-title" class="form-label">Product Title</label>
   <input type="text" id="product_title" value=<?php echo $product_title; ?> name="product_title" class="form-control" required>
  </div>
        
        <div class="form-outline mb-4 w-50 m-auto">
         <label for="product_price" class="form-label" > Product price</label>
         <input type="text" name="product_price" id="product_price" value=<?php echo $product_price; ?> class="form-control" autocompleter="off" required>

        </div>
        <div class="form-outline mb-4 w-50 m-auto">
         <input type="submit" name="update_product"  class="btn btn-info mb-3 mx-3"  value="Update Product" >

        </div>
</form>
</div>
