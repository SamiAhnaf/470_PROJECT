<h3 class="text-center text-success">All Users</h3>
<table class="table table-bordered mt-5">
 <thead class="bg-info">
<?php   
 $get_user="select * from `user_table`";
 $user_result=mysqli_query($con,$get_user);
 $user_count=mysqli_num_rows( $user_result);
 
echo "  <tr class='text-center'> 
<th>SI No</th>
<th>Username</th>
<th>User Email</th>
<th>User Address</th>
<th>User Mobile</th>
</tr>
</thead>
<tbody class='bg-secondary text-light text-center'> ";
if( $user_count==0){
    echo " <h2 class='bg-danger text-center mt-5'>No Users Singed in </h2>";
}
else {
    $number=0;
    while($user_data=mysqli_fetch_assoc( $user_result)){
        $user_id = $user_data['user_id'];
        $user_name= $user_data['user_name'];
       $user_email= $user_data['user_email'];
       $user_address= $user_data['user_address'];
       $user_phone= $user_data['user_phone'];
    
       $number++;
       echo " <tr>
       <td>$number</td>
       <td>  $user_name</td>
       <td>$user_email</td>
       <td> $user_address</td>
       <td> $user_phone</td> 
   </tr> ";
    }
}


?>
</tbody>
</table>
