<?php  
//including connection file
include('../includes/connect.php');
include('../function/common_function.php');

//session varible for login redirection
if(!isset($_SESSION['username'])){
  echo "<script>window.open('admin_login.php','_self')</script> ";
}
else {
  echo "<script>window.open('admin_login.php','_self')</script> ";

}

  

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin Dashboard</title>
    <!-- bootstrap link  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <!-- fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    <!-- mycss  -->
    <link rel="stylesheet" href="../mystyle.css">
    <style>
  .product_img {
    width: 100px;
    object-fit:contain;
  }

        </style>
</head>
<body>
<div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-info">

        <div class="container-fluid">
        <a class="navbar-brand" href="#"><img src="../images/pic-1.png" alt="" class="logo"></a>
        <nav class="navbar navbar-expand-lg " > 
            
        <ul class="navbar-nav ">
                     <?php   
                     if(!isset($_SESSION['username'])){

                      echo "
                      <li class='nav-item'>
                                      <a class='nav-link' href='#'>Welcome Guest</a>
                                  </li> ";
                   }
                   else {
                  
                      echo "
                      <li class='nav-item'>
                          <a class='nav-link' href='#'>Welcome {$_SESSION['username']}</a>
                      </li>
                  ";
                  
                   }
                     
                     
                     
                     ?>



            </ul>
        </nav>
        </div>
        </nav>
<!-- second child -->
<div class="bg-light">
    <h3 class="text-center">Manage Details</h3>
</div>
 
<!-- third child  -->
<div class="row">
    <div class="container-fluid">
    <div class="col-md-12 p-1 bg-secondary d-flex align-items-center">
        <div>
        <a src="#"> <img src="../images/pic-1.png" alt="" class="admin-image">  </a>
        <?php   
                     if(!isset($_SESSION['username'])){

                      echo "
                      <p class=' text-light text-center'> Admin Name </p>";
                   }
                   else {
                  
                      echo "
                      <p class=' text-light text-center'> Welcome {$_SESSION['username']} </p>
                  ";
                  
                   }
                     
                     
                     
                     ?>


      
        </div>
          <div class="button text-center p-5">
          <button ><a href="insert_product.php" class=" nav-link text-light bg-info my-1 p-2">Insert Product</a></button>
          <button ><a href="index.php?view_product" class=" nav-link text-light bg-info my-1 p-2">View Product</a></button>
          <button ><a href="index.php?insert_category" class=" nav-link text-light bg-info my-1 p-2"> Insert Categories</a></button>
          <!-- <button ><a href="" class=" nav-link text-light bg-info my-1 p-2"> View Categories</a></button> -->
          <button ><a href="index.php?insert_brand" class=" nav-link text-light bg-info my-1 p-2">Insert Brands</a></button>
          <!-- <button ><a href="" class=" nav-link text-light bg-info my-1 p-2">View Brands</a></button> -->
          <button ><a href="index.php?list_orders" class=" nav-link text-light bg-info my-1 p-2">All Orders</a></button>
          <button ><a href="index.php?list_payments" class=" nav-link text-light bg-info my-1 p-2">All Payments</a></button>
          <button ><a href="index.php?list_users" class=" nav-link text-light bg-info my-1 p-2">List Users</a></button>
          
<?php    
           if(!isset($_SESSION['username'])){

            echo " <button'>
            <a class='nav-link text-light bg-info my-1 p-2' href='admin_login.php'>Login</a>
           </button>";
                
            }
            else {
               echo " <button'>
               <a class='nav-link text-light bg-info my-1 p-2' href='admin_logout.php'>Logout</a>
           </button>";
               
            }

     ?>
          
          </div>

    </div>
</div>
</div>

</div>


<div class="container my-5 pb-5">
<?php 
if (isset($_GET['insert_category'])) {
 include('insert_categories.php');
}
if (isset($_GET['insert_brand'])) {
 include('insert_brands.php');
}
if (isset($_GET['view_product'])) {
 include('view_product.php');
}
if (isset($_GET['delete_product'])) {
 include('delete_product.php');
}
if (isset($_GET['list_orders'])) {
 include('list_orders.php');
}
if (isset($_GET['list_payments'])) {
 include('list_payments.php');
}
if (isset($_GET['list_users'])) {
 include('list_users.php');
}
?>

</div>

  <!-- footer  -->
  <?php 
         include("../includes/footer.php");
        ?>

<!-- js link  -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
</body>
</html>